package vo;

public class test {
	private String userid;
	
	
	public test() {
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String toString() {
		return "test [userid=" + userid + "]";
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public test(String userid) {
		super();
		this.userid = userid;
	}
	
	
}
